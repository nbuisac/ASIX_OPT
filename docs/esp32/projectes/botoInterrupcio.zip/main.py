from machine import Pin
from time import sleep
gt = Pin(33, Pin.IN)
i = 0

def interrupcio(pin):
    global i
    i += 1

gt.irq(handler=interrupcio, trigger=Pin.IRQ_RISING)
while True:
    print(i)
    sleep(1)
