from machine import Pin
from time import sleep

def encenLlums(_):
    vledR = ledR.value()
    vledG = ledG.value()
    vledB = ledB.value()
    ledR.on()
    ledG.on()
    ledB.on()
    sleep(1)
    ledR.value(vledR)
    ledG.value(vledG)
    ledB.value(vledB)

bt = Pin(19, Pin.IN, Pin.PULL_DOWN)
bt.irq(handler=encenLlums, trigger=Pin.IRQ_RISING)
ledR = Pin(25, Pin.OUT)
ledG = Pin(26, Pin.OUT)
ledB = Pin(27, Pin.OUT)
ledR.off()
ledG.off()
ledB.off()
i = 0
while True:
    ledR.on()
    ledG.off()
    ledB.off()
    ## comprovació del pulsador
    sleep(0.5)
    ## comprovació del pulsador
    ledR.off()
    ledG.on()
    ledB.off()
    ## comprovació del pulsador
    sleep(0.5)
    ## comprovació del pulsador
    ledR.off()
    ledG.off()
    ledB.on()
    ## comprovació del pulsador
    sleep(0.5)
    ## comprovació del pulsador
