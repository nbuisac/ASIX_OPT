from machine import Pin
from time import sleep
import random

LED_RED_PINS = [25, 33, 32, 27, 26 ]
ok = True

def compte_enrere(l):
    for p in l:
        p.on()
        sleep(1)
        if not ok: break

def apaga(que):
    if isinstance(que, list):
        for i in que:
            apaga(i)
    else:
        que.off()

def normal(l):
    if ok:
      compte_enrere(l)
    if ok:
      sleep(random.randint(2, 5))
    if ok:
      apaga(l)

# Inicialitzem tot apagat
red_leds = []
for pin in LED_RED_PINS:
    p = Pin(pin, Pin.OUT)
    red_leds.append(p)
    p.off()


normal(red_leds)